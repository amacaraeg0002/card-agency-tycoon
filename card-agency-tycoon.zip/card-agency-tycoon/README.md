# Agency Row — Card Agency Tycoon

Client-side sports agency game with React 19, TypeScript, Vite, Tailwind CSS, Canvas, Lucide and Zustand.

## Local development

Node 22.12 or newer is recommended.

```sh
npm ci
npm test
npm run build
npm run dev
```

The site opens directly onto an interactive office and manual editing bay. Other tabs provide the full clipping studio, packs, and card binder. The roster uses real athletes and verified ESPN player photos. Card ratings, rarities, and earnings are game values, not ESPN ratings. Historic cards use general player portraits; see PHOTO_CREDITS.md for sources.

## Rules and assumptions

- All stated view, cash, quirk, coating, quicksell and staff wage formulas are implemented without intermediate currency rounding.
- The specification's gap above 0.535 through 0.536 counts as Good.
- Staff have the specified wages, so their initial operation loses cash while building mastery. They start paused and pause automatically if a cycle is unaffordable.
- Sponsor upgrades affect manual cash only. Coatings boost displayed OVR; quicksell floors use original OVR.
- Each assigned desk consumes a card copy. The first binder copy, locked cards and assigned copies cannot sell. Mastery is shared among copies of a card.
- Superfractor serials are local to the save; global uniqueness requires a server.
- Starting cash is $2,500 with one Jackson Holliday card. Packs use persisted xorshift32 randomness and a fixed starting seed. Purchased results and reveal states survive refreshes.
- Positive sports trends last 180 active-play seconds. Other sports receive -15%, with Greatness immunity. Defensive cycles alternate every 30 active-play seconds.
- One auto clip per running desk per 10 active-play seconds. Hidden and closed pages do not produce or incur wages.
- Save key: `agency_tycoon_save_v1`. Web Locks enforce a single active writer tab. Reset is confirmed in Settings.

`npm test` covers economic boundaries, pack transactions, staff assignments, save invariants, and optional agent-tool behavior. The deployed site is a static export from `dist/`.

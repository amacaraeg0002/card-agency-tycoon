import { CARDS,PACKS,PARALLELS,RARITIES,STAFF_SPECS } from './cardData';
import { SPORTS } from './types';
import type { Card,CardId,GameSave,PackId,StaffRole,Trend,Yield } from './types';
export const SAVE_KEY='agency_tycoon_save_v1';
export const money=(v:number)=>v.toLocaleString('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2});
export const compact=(v:number)=>Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:1}).format(v);
export function initialGame():GameSave{return {cash:2500,totalViews:0,inventory:{rookie:{count:1,views:0,locked:false}},activeCard:'rookie',staff:[],sponsor:0,rng:0x9e3779b9,clockMs:0,nextId:1,pending:null};}
export function triangle(t:number,cycle:number){return Math.abs(2*((Math.max(0,t)/cycle)%1)-1);}
export function cycleDuration(card:Card){return [1.2,1.11,1.02,.93,.84,.75][RARITIES.indexOf(card.rarity)];}
export function timing(x:number):{grade:Yield['grade'];multiplier:number}{
 if(!Number.isFinite(x)||x<0||x>1)throw new RangeError('Invalid needle position');
 if(x>=.465&&x<=.535)return {grade:'Perfect',multiplier:2.5};
 if(x>=.4&&x<=.6)return {grade:'Good',multiplier:1};
 return {grade:'Flop',multiplier:.25};
}
export function parallelTier(views:number){let tier=0;for(let i=1;i<PARALLELS.length;i++)if(views/100>=PARALLELS[i].xp)tier=i;return tier;}
export function trendAt(ms:number):Trend{return {sport:SPORTS[Math.floor(ms/180000)%6],multiplier:1.5,otherMultiplier:.85,remainingMs:180000-ms%180000,defensive:Math.floor(ms/30000)%2===1};}
export function calculateYield(card:Card,views:number,x:number|null,trend:Trend,sponsor=1,wageRate=0):Yield{
 const release=x===null?{grade:'Auto' as const,multiplier:1}:timing(x);
 let quirk=1;
 if(card.quirks.includes('#GREATNESS'))quirk*=3;
 if(card.quirks.includes('#SHOWTIME')&&x!==null&&x>=.49&&x<=.51)quirk*=1.75;
 if(card.quirks.includes('#PickSix')&&trend.defensive)quirk*=1.6;
 if(card.quirks.includes('#WalkoffKO')&&release.grade==='Perfect')quirk*=2;
 let trendM=card.sport===trend.sport?trend.multiplier:trend.otherMultiplier;
 if(card.quirks.includes('#GREATNESS'))trendM=Math.max(1,trendM);
 const produced=Math.floor(card.baseViews*release.multiplier*quirk*PARALLELS[parallelTier(views)].multiplier*trendM);
 const gross=produced/1000*card.cpm*(x===null?1:sponsor),wage=produced/1000*wageRate;
 return {grade:release.grade,views:produced,gross,wage,net:gross-wage};
}
export function quicksellValue(card:Card){const o=card.ovr;return (o<65?5:o<75?25:o<80?100:o<85?750:o<90?4000:10000)+(card.historic?1500:0);}
export function assignedCopies(g:GameSave,id:CardId,exclude?:number){return Number(g.activeCard===id)+g.staff.filter(s=>s.id!==exclude&&s.cardId===id).length;}
export function canSell(g:GameSave,id:CardId){const o=g.inventory[id];return !!o&&!o.locked&&o.count>Math.max(1,assignedCopies(g,id));}
export function sellDuplicate(g:GameSave,id:CardId):GameSave{if(!canSell(g,id))return g;const o=g.inventory[id]!;return {...g,cash:g.cash+quicksellValue(CARDS[id]),inventory:{...g.inventory,[id]:{...o,count:o.count-1}}};}
export function canAssign(g:GameSave,id:CardId,desk:number|null){
 const o=g.inventory[id];if(!o)return false;
 if(desk===null)return o.count>g.staff.filter(s=>s.cardId===id).length;
 const s=g.staff.find(s=>s.id===desk);return !!s&&RARITIES.indexOf(CARDS[id].rarity)<=STAFF_SPECS[s.role].maxRank&&o.count>assignedCopies(g,id,desk);
}
export function assignCard(g:GameSave,id:CardId|null,desk:number|null):GameSave{
 if(id===null){if(desk===null)return g;return {...g,staff:g.staff.map(s=>s.id===desk?{...s,cardId:null,paused:true}:s)};}
 if(!canAssign(g,id,desk))return g;
 return desk===null?{...g,activeCard:id}:{...g,staff:g.staff.map(s=>s.id===desk?{...s,cardId:id}:s)};
}
export function hireStaff(g:GameSave,role:StaffRole):GameSave{const cost=STAFF_SPECS[role].cost;if(g.cash<cost||g.staff.length>=4)return g;return {...g,cash:g.cash-cost,nextId:g.nextId+1,staff:[...g.staff,{id:g.nextId,role,cardId:null,paused:true}]};}
export const sponsorCost=(level:number)=>1000*2**level;
export const sponsorMultiplier=(g:GameSave)=>1+g.sponsor*.25;
export function nextRandom(seed:number):[number,number]{let x=seed>>>0;x^=x<<13;x^=x>>>17;x^=x<<5;const n=x>>>0;return [n,n/4294967296];}
export function openPack(g:GameSave,kind:PackId):GameSave{
 const p=PACKS[kind];if(g.pending||g.cash<p.price)return g;let rng=g.rng;
 const cards=Array.from({length:p.count},()=>{let roll:number;[rng,roll]=nextRandom(rng);let sum=0,id=p.odds[p.odds.length-1][0];for(const [candidate,chance] of p.odds){sum+=chance;if(roll<sum){id=candidate;break;}}return {cardId:id,revealed:false,duplicate:false};});
 return {...g,cash:g.cash-p.price,rng,nextId:g.nextId+1,pending:{id:g.nextId,kind,cards}};
}
export function revealCard(g:GameSave,index:number):GameSave{
 const p=g.pending;if(!p||!Number.isInteger(index))return g;const pull=p.cards[index];if(!pull||pull.revealed)return g;const o=g.inventory[pull.cardId];
 return {...g,inventory:{...g.inventory,[pull.cardId]:{count:(o?.count??0)+1,views:o?.views??0,locked:o?.locked??false}},pending:{...p,cards:p.cards.map((c,i)=>i===index?{...c,revealed:true,duplicate:!!o}:c)}};
}
export function awardViews(g:GameSave,id:CardId,r:Yield):GameSave{
 const o=g.inventory[id];if(!o)return g;
 const cash=g.cash+r.net,total=g.totalViews+r.views,views=o.views+r.views;
 if(!Number.isFinite(cash)||cash<0||cash>Number.MAX_SAFE_INTEGER||!Number.isSafeInteger(total)||!Number.isSafeInteger(views))throw Error('Agency numerical limit reached.');
 return {...g,cash,totalViews:total,inventory:{...g.inventory,[id]:{...o,views}}};
}
export function stepSecond(g:GameSave){
 let next={...g,clockMs:g.clockMs+1000};const productions:{desk:number;cardId:CardId;result:Yield}[]=[];let paused=0;
 if(next.clockMs%10000!==0)return {game:next,productions,paused};
 const trend=trendAt(next.clockMs);
 for(const desk of next.staff){if(desk.paused||!desk.cardId)continue;const o=next.inventory[desk.cardId];if(!o)continue;
 const result=calculateYield(CARDS[desk.cardId],o.views,null,trend,1,STAFF_SPECS[desk.role].wage);
 if(next.cash+result.net<0){paused++;next={...next,staff:next.staff.map(s=>s.id===desk.id?{...s,paused:true}:s)};continue;}
 next=awardViews(next,desk.cardId,result);productions.push({desk:desk.id,cardId:desk.cardId,result});}
 return {game:next,productions,paused};
}

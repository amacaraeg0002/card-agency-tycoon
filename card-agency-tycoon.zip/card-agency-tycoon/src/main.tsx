import { Component,StrictMode } from 'react';
import type { ErrorInfo,ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
class ErrorBoundary extends Component<{children:ReactNode},{failed:boolean}>{
 state={failed:false};
 static getDerivedStateFromError(){return {failed:true};}
 componentDidCatch(error:Error,info:ErrorInfo){console.error('Agency rendering failed',error,info.componentStack);}
 render(){return this.state.failed?<main className="flex min-h-dvh items-center justify-center p-8"><div className="panel max-w-md p-8"><h1 className="text-2xl">The agency hit a rendering error.</h1><p className="mt-3 text-base text-[#a4afb6]">Reload to restore your most recent saved progress.</p><button className="primary-button mt-5" onClick={()=>location.reload()}>Reload agency</button></div></main>:this.props.children;}
}
const root=document.getElementById('root');if(!root)throw Error('Missing application root');
createRoot(root).render(<StrictMode><ErrorBoundary><App/></ErrorBoundary></StrictMode>);

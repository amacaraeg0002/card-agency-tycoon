import { create } from 'zustand';
import { createJSONStorage,persist } from 'zustand/middleware';
import { CARDS } from './cardData';
import { SAVE_KEY,assignCard,awardViews,calculateYield,hireStaff,initialGame,money,openPack,revealCard,sellDuplicate,sponsorCost,sponsorMultiplier,stepSecond,trendAt } from './economy';
import { restoreSave,safeStorage } from './persistence';
import type { CardId,GameEvent,GameSave,PackId,StaffRole,Tab,Yield } from './types';
interface Store {game:GameSave;tab:Tab;events:GameEvent[];sequence:number;message:string;lastManualAt:number;advance:()=>void;manual:(x:number)=>Yield|null;buyPack:(kind:PackId)=>void;reveal:(index:number)=>CardId|null;finishPack:()=>void;sell:(id:CardId)=>void;lock:(id:CardId)=>void;assign:(id:CardId|null,desk:number|null)=>boolean;hire:(role:StaffRole)=>void;pause:(desk:number)=>void;upgrade:()=>void;reset:()=>void;navigate:(tab:Tab)=>void;}
export const useGameStore=create<Store>()(persist((set,get)=>({
 game:initialGame(),tab:'floor',events:[],sequence:0,message:'Welcome to Agency Row. Your first card and $2,500 are ready.',lastManualAt:-Infinity,
 navigate:tab=>set({tab}),
 advance:()=>{const s=get(),r=stepSecond(s.game);let sequence=s.sequence;const events=r.productions.map(p=>({...p,id:++sequence,at:performance.now()}));set({game:r.game,sequence,events:[...s.events,...events].slice(-30),...(r.paused?{message:'A desk paused because cash could not cover its cycle.'}:{})});},
 manual:x=>{const s=get(),now=performance.now();if(now-s.lastManualAt<900||!Number.isFinite(x)||x<0||x>1)return null;const id=s.game.activeCard,o=s.game.inventory[id];if(!o)return null;const r=calculateYield(CARDS[id],o.views,x,trendAt(s.game.clockMs),sponsorMultiplier(s.game));const e:GameEvent={id:s.sequence+1,desk:null,at:now,cardId:id,result:r};set({game:awardViews(s.game,id,r),sequence:e.id,events:[...s.events,e].slice(-30),lastManualAt:now,message:`${r.grade} release · ${money(r.net)} earned`});return r;},
 buyPack:kind=>{const prev=get().game,game=openPack(prev,kind);set({game,message:prev===game?'Finish your open pack or earn more cash.':'Pack secured. Tap each card to reveal.'});},
 reveal:index=>{const prev=get().game,game=revealCard(prev,index);if(prev===game)return null;const id=game.pending!.cards[index].cardId;set({game,message:`${CARDS[id].name} joined the agency.`});return id;},
 finishPack:()=>{const g=get().game;if(g.pending?.cards.every(c=>c.revealed))set({game:{...g,pending:null},message:'Your roster is growing. Make the next clip count.'});},
 sell:id=>{const prev=get().game,game=sellDuplicate(prev,id);set({game,message:game===prev?'Only unlocked, unassigned duplicates can sell.':`Duplicate sold for ${money(game.cash-prev.cash)}.`});},
 lock:id=>{const g=get().game,o=g.inventory[id];if(o)set({game:{...g,inventory:{...g.inventory,[id]:{...o,locked:!o.locked}}},message:o.locked?'Binder lock removed.':'Card locked to binder.'});},
 assign:(id,desk)=>{const prev=get().game,game=assignCard(prev,id,desk);set({game,message:game===prev?'No eligible free copy available.':'Desk assignment updated.'});return game!==prev;},
 hire:role=>{const prev=get().game,game=hireStaff(prev,role);set({game,message:prev===game?'Not enough cash or no open desks.':'Editor hired. Assign a card, then resume the desk.'});},
 pause:desk=>{const g=get().game;set({game:{...g,staff:g.staff.map(s=>s.id===desk&&s.cardId?{...s,paused:!s.paused}:s)}});},
 upgrade:()=>{const g=get().game,cost=sponsorCost(g.sponsor);if(g.sponsor>=8||g.cash<cost){set({message:'Sponsor upgrade unavailable.'});return;}set({game:{...g,cash:g.cash-cost,sponsor:g.sponsor+1},message:'Deal signed. Manual cash yield increased by 0.25×.'});},
 reset:()=>set({game:initialGame(),tab:'floor',events:[],sequence:0,lastManualAt:-Infinity,message:'New agency. New possibilities.'})
}),{name:SAVE_KEY,version:1,storage:createJSONStorage(()=>safeStorage),skipHydration:true,partialize:s=>({game:s.game}),merge:(saved,current)=>({...current,game:restoreSave(saved)})}));

import type { StateStorage } from 'zustand/middleware';
import { CARD_IDS,PACKS,STAFF_ROLES,isCardId } from './cardData';
import { assignedCopies,canAssign,initialGame } from './economy';
import type { GameSave,StaffRole } from './types';
let issue='';
export const getStorageIssue=()=>issue;
const record=(v:unknown):v is Record<string,unknown>=>typeof v==='object'&&v!==null&&!Array.isArray(v);
const integer=(v:unknown,min=0):v is number=>Number.isSafeInteger(v)&&(v as number)>=min;
export function validSave(v:unknown):v is GameSave{
 if(!record(v)||typeof v.cash!=='number'||!Number.isFinite(v.cash)||v.cash<0||v.cash>Number.MAX_SAFE_INTEGER||!integer(v.totalViews)||!integer(v.clockMs)||v.clockMs%1000!==0||!integer(v.nextId,1)||!integer(v.rng,1)||v.rng>0xffffffff||!isCardId(v.activeCard)||!record(v.inventory)||!integer(v.sponsor)||v.sponsor>8||!Array.isArray(v.staff)||v.staff.length>4)return false;
 let views=0;
 for(const [id,o] of Object.entries(v.inventory)){if(!isCardId(id)||!record(o)||!integer(o.count,1)||!integer(o.views)||typeof o.locked!=='boolean')return false;views+=o.views;}
 if(views!==v.totalViews||!v.inventory[v.activeCard])return false;
 const ids=new Set<number>();
 for(const s of v.staff){if(!record(s)||!integer(s.id,1)||s.id>=v.nextId||ids.has(s.id)||!STAFF_ROLES.includes(s.role as StaffRole)||typeof s.paused!=='boolean'||(s.cardId!==null&&!isCardId(s.cardId)))return false;ids.add(s.id);}
 if(v.pending!==null){const p=v.pending;if(!record(p)||!integer(p.id,1)||p.id>=v.nextId||ids.has(p.id)||(p.kind!=='starter'&&p.kind!=='marquee')||!Array.isArray(p.cards)||p.cards.length!==PACKS[p.kind].count)return false;const allowed=PACKS[p.kind].odds.map(([id])=>id);for(const c of p.cards){if(!record(c)||!isCardId(c.cardId)||!allowed.includes(c.cardId)||typeof c.revealed!=='boolean'||typeof c.duplicate!=='boolean'||(c.revealed&&!v.inventory[c.cardId]))return false;}}
 const g=v as unknown as GameSave;
 for(const id of CARD_IDS)if(assignedCopies(g,id)>(g.inventory[id]?.count??0))return false;
 for(const s of g.staff)if(s.cardId&&!canAssign(g,s.cardId,s.id))return false;
 return true;
}
export function restoreSave(v:unknown):GameSave{if(record(v)&&validSave(v.game))return v.game;issue='This save could not be restored. A new agency was started.';return initialGame();}
export const safeStorage:StateStorage={
 getItem(name){try{const raw=localStorage.getItem(name);if(!raw)return null;JSON.parse(raw);return raw;}catch{issue='Saved data is unavailable. Progress may be session-only.';return null;}},
 setItem(name,value){try{localStorage.setItem(name,value);}catch{issue='Saving failed. Free browser storage before closing.';}},
 removeItem(name){try{localStorage.removeItem(name);}catch{issue='The saved game could not be removed.';}}
};

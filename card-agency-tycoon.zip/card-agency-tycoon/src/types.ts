export const SPORTS = ['Basketball','Baseball','Football','Soccer','Tennis','Combat Sports'] as const;
export type Sport = typeof SPORTS[number];
export type Rarity = 'Common'|'Bronze'|'Silver'|'Gold'|'Diamond'|'Mythic';
export type CardId = 'rookie'|'comeback'|'gunslinger'|'maestro'|'brawler'|'phenom'|'historic-tennis'|'historic-combat'|'historic-soccer'|'historic-football';
export type Quirk = '#SHOWTIME'|'#GREATNESS'|'#PickSix'|'#WalkoffKO';
export type PackId = 'starter'|'marquee';
export type StaffRole = 'intern'|'editor'|'producer';
export type Tab = 'floor'|'studio'|'vault'|'binder';
export interface Card { id:CardId; name:string; sport:Sport; rarity:Rarity; ovr:number; baseViews:number; cpm:number; historic:boolean; quirks:Quirk[]; photo:string; photoSource:string; photoFit:'contain'|'cover'; color:string; }
export interface Owned { count:number; views:number; locked:boolean; }
export interface Staff { id:number; role:StaffRole; cardId:CardId|null; paused:boolean; }
export interface Pull { cardId:CardId; revealed:boolean; duplicate:boolean; }
export interface GameSave { cash:number; totalViews:number; inventory:Partial<Record<CardId,Owned>>; activeCard:CardId; staff:Staff[]; sponsor:number; rng:number; clockMs:number; nextId:number; pending:{id:number;kind:PackId;cards:Pull[]}|null; }
export interface Trend { sport:Sport; multiplier:number; otherMultiplier:number; remainingMs:number; defensive:boolean; }
export interface Yield { grade:'Perfect'|'Good'|'Flop'|'Auto'; views:number; gross:number; wage:number; net:number; }
export interface GameEvent { id:number; desk:number|null; at:number; cardId:CardId; result:Yield; }

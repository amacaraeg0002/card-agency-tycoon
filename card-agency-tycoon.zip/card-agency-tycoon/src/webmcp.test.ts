import { describe,expect,it } from 'vitest';
import { registerGameTools } from './webmcp';
import { useGameStore } from './useGameStore';
describe('agent tools',()=>{
 it('registers, reads, navigates, rejects invalid input, and unregisters',()=>{
 const tools=new Map<string,{execute:(input:unknown)=>unknown;readonly:boolean;schema:object;signal?:AbortSignal}>();
 const cleanup=registerGameTools({registerTool:(t,o)=>{tools.set(t.name,{execute:t.execute,readonly:t.annotations.readOnlyHint,schema:t.inputSchema,signal:o?.signal});}});
 expect([...tools.keys()]).toEqual(['read_agency_overview','navigate_agency_screen']);
 const read=tools.get('read_agency_overview')!,nav=tools.get('navigate_agency_screen')!;
 expect(read.readonly).toBe(true);expect(nav.readonly).toBe(false);expect(read.execute({})).toMatchObject({cash:2500,ownedCards:1});
 expect(nav.execute({screen:'studio'})).toEqual({screen:'studio'});expect(useGameStore.getState().tab).toBe('studio');
 expect(()=>nav.execute({screen:'missing'})).toThrow();expect(()=>read.execute({purchase:true})).toThrow();expect(useGameStore.getState().tab).toBe('studio');
 useGameStore.getState().navigate('floor');cleanup();expect(nav.signal?.aborted).toBe(true);
 });
});

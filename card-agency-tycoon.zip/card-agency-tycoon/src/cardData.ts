import type { Card,CardId,PackId,Rarity,StaffRole } from './types';
export const RARITIES:Rarity[]=['Common','Bronze','Silver','Gold','Diamond','Mythic'];
export const PARALLELS=[
 {name:'Raw Base',xp:0,multiplier:1},
 {name:'Bronze Foil',xp:2500,multiplier:1.1},
 {name:'Silver Refractor',xp:10000,multiplier:1.25},
 {name:'Gold Sparkle',xp:35000,multiplier:1.45},
 {name:'Diamond Prismatic',xp:100000,multiplier:1.75},
 {name:'Superfractor 1/1 Nebula',xp:300000,multiplier:2.25}
] as const;
export const CARDS:Record<CardId,Card>={
 rookie:{id:'rookie',name:'Jackson Holliday',sport:'Baseball',rarity:'Common',ovr:62,baseViews:300,cpm:1.5,historic:false,quirks:[],photo:'players/jackson-holliday.png',photoSource:'https://www.espn.com/mlb/player/_/id/5080633/jackson-holliday',photoFit:'contain',color:'#aac4a2'},
 comeback:{id:'comeback',name:'LeBron James',sport:'Basketball',rarity:'Mythic',ovr:99,baseViews:35000,cpm:18,historic:true,quirks:['#GREATNESS','#SHOWTIME'],photo:'players/lebron-james.png',photoSource:'https://www.espn.com/nba/player/_/id/1966/lebron-james',photoFit:'contain',color:'#c9a4ff'},
 gunslinger:{id:'gunslinger',name:'Patrick Mahomes',sport:'Football',rarity:'Diamond',ovr:88,baseViews:12000,cpm:9.5,historic:false,quirks:['#PickSix'],photo:'players/patrick-mahomes.png',photoSource:'https://www.espn.com/nfl/player/_/id/3139477/patrick-mahomes',photoFit:'contain',color:'#90ceef'},
 maestro:{id:'maestro',name:'Lionel Messi',sport:'Soccer',rarity:'Gold',ovr:82,baseViews:4000,cpm:5,historic:false,quirks:[],photo:'players/lionel-messi.png',photoSource:'https://www.espn.com/soccer/player/_/id/45843/lionel-messi',photoFit:'contain',color:'#e7c878'},
 brawler:{id:'brawler',name:'Alex Pereira',sport:'Combat Sports',rarity:'Silver',ovr:77,baseViews:1800,cpm:3.25,historic:false,quirks:['#WalkoffKO'],photo:'players/alex-pereira-editorial.jpg',photoSource:'https://www.espn.com/mma/fighter/_/id/4705658/alex-pereira',photoFit:'cover',color:'#c9d5db'},
 phenom:{id:'phenom',name:'Coco Gauff',sport:'Tennis',rarity:'Bronze',ovr:71,baseViews:800,cpm:2.1,historic:false,quirks:[],photo:'players/coco-gauff.png',photoSource:'https://www.espn.com/tennis/player/_/id/3626/coco-gauff',photoFit:'contain',color:'#d5a683'},
 'historic-tennis':{id:'historic-tennis',name:'Serena Williams',sport:'Tennis',rarity:'Bronze',ovr:74,baseViews:950,cpm:2.4,historic:true,quirks:[],photo:'players/serena-williams.png',photoSource:'https://www.espn.com/tennis/player/_/id/394/serena-williams',photoFit:'contain',color:'#d5a683'},
 'historic-combat':{id:'historic-combat',name:'Conor McGregor',sport:'Combat Sports',rarity:'Silver',ovr:79,baseViews:2200,cpm:3.6,historic:true,quirks:['#WalkoffKO'],photo:'players/conor-mcgregor.png',photoSource:'https://www.espn.com/mma/fighter/_/id/3022677/conor-mcgregor',photoFit:'contain',color:'#c9d5db'},
 'historic-soccer':{id:'historic-soccer',name:'Cristiano Ronaldo',sport:'Soccer',rarity:'Gold',ovr:84,baseViews:5000,cpm:5.5,historic:true,quirks:[],photo:'players/cristiano-ronaldo.jpg',photoSource:'https://www.espn.com/soccer/player/_/id/22774/cristiano-ronaldo',photoFit:'cover',color:'#e7c878'},
 'historic-football':{id:'historic-football',name:'Tom Brady',sport:'Football',rarity:'Diamond',ovr:89,baseViews:14000,cpm:10,historic:true,quirks:['#PickSix'],photo:'players/tom-brady.png',photoSource:'https://www.espn.com/nfl/player/_/id/2330/tom-brady',photoFit:'contain',color:'#90ceef'}
};
export const CARD_IDS=Object.keys(CARDS) as CardId[];
export function isCardId(id:unknown):id is CardId{return typeof id==='string'&&Object.hasOwn(CARDS,id);}
export const STAFF_ROLES:StaffRole[]=['intern','editor','producer'];
export const STAFF_SPECS:Record<StaffRole,{name:string;cost:number;wage:number;maxRank:number}>={
 intern:{name:'Intern',cost:500,wage:10,maxRank:2},editor:{name:'Staff Editor',cost:2500,wage:35,maxRank:3},producer:{name:'Senior Producer',cost:10000,wage:120,maxRank:5}
};
export const PACKS:Record<PackId,{name:string;price:number;count:number;odds:[CardId,number][]}>={
 starter:{name:'Prospect Starter Pack',price:250,count:3,odds:[['rookie',.595],['phenom',.28],['brawler',.1],['maestro',.02],['gunslinger',.0045],['comeback',.0005]]},
 marquee:{name:'Marquee 2016 Vault Box',price:5000,count:2,odds:[['historic-tennis',.4],['historic-combat',.36],['historic-soccer',.18],['historic-football',.05],['comeback',.01]]}
};
export const QUIRKS={ '#GREATNESS':'3× views. Immune to negative trends.', '#SHOWTIME':'1.75× views on an exact-center release (0.49–0.51).', '#PickSix':'1.6× views during defensive highlight cycles.', '#WalkoffKO':'2× views on Perfect manual releases.' };

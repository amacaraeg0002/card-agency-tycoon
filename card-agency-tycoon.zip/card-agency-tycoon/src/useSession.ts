import { useEffect,useState } from 'react';
import { SAVE_KEY } from './economy';
import { useGameStore } from './useGameStore';
export function useSession(){
 const [ready,setReady]=useState(false),[error,setError]=useState('');
 useEffect(()=>{let disposed=false;let release:(()=>void)|undefined;const ctrl=new AbortController();
 if(!navigator.locks){setError('Please use a modern browser to open your agency.');return;}
 void navigator.locks.request(SAVE_KEY,{signal:ctrl.signal},async()=>{if(disposed)return;await useGameStore.persist.rehydrate();if(disposed)return;setReady(true);await new Promise<void>(resolve=>{release=resolve;if(disposed)resolve();});}).catch((e:unknown)=>{if(!disposed)setError(e instanceof Error?e.message:'Your agency could not be opened.');});
 return ()=>{disposed=true;ctrl.abort();release?.();};},[]);
 useEffect(()=>{if(!ready)return;let frame=0,previous=performance.now(),acc=0;
 const tick=(now:number)=>{const elapsed=Math.min(250,Math.max(0,now-previous));previous=now;if(document.hidden)acc=0;else{acc+=elapsed;if(acc>=1000){acc-=1000;useGameStore.getState().advance();}}frame=requestAnimationFrame(tick);};
 const visibility=()=>{previous=performance.now();acc=0;};document.addEventListener('visibilitychange',visibility);frame=requestAnimationFrame(tick);
 return ()=>{cancelAnimationFrame(frame);document.removeEventListener('visibilitychange',visibility);};},[ready]);
 return {ready,error};
}

import { CARDS } from './cardData';
import { useGameStore } from './useGameStore';
import type { Tab } from './types';
interface Tool {name:string;description:string;inputSchema:object;annotations:{readOnlyHint:boolean};execute:(input:unknown)=>unknown;}
export interface ModelContext {registerTool:(tool:Tool,options?:{signal?:AbortSignal})=>void|Promise<void>;}
export function registerGameTools(context:ModelContext){
 const ctrl=new AbortController();
 const register=(tool:Tool)=>{try{void Promise.resolve(context.registerTool(tool,{signal:ctrl.signal})).catch(()=>{});}catch{/* Optional browser capability; gameplay remains available. */}};
 register({name:'read_agency_overview',description:'Read the saved cash, views, roster, active card, and current screen.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:input=>{if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length)throw Error('Expected an empty object.');const s=useGameStore.getState();return {cash:s.game.cash,totalViews:s.game.totalViews,activeCard:CARDS[s.game.activeCard].name,ownedCards:Object.keys(s.game.inventory).length,staff:s.game.staff.length,screen:s.tab};}});
 register({name:'navigate_agency_screen',description:'Open an agency screen. This does not purchase, reveal, sell, or produce a clip.',inputSchema:{type:'object',properties:{screen:{type:'string',enum:['floor','studio','vault','binder']}},required:['screen'],additionalProperties:false},annotations:{readOnlyHint:false},execute:input=>{if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length!==1||!('screen' in input)||!['floor','studio','vault','binder'].includes(String(input.screen)))throw Error('A valid screen is required.');const screen=input.screen as Tab;useGameStore.getState().navigate(screen);return {screen:useGameStore.getState().tab};}});
 return ()=>ctrl.abort();
}

import { useEffect,useId,useRef } from 'react';
import type { ReactNode } from 'react';
import { X } from 'lucide-react';
export function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:ReactNode}){
 const ref=useRef<HTMLDialogElement>(null),id=useId();
 useEffect(()=>{const d=ref.current;if(d&&!d.open)d.showModal();return ()=>{if(d?.open)d.close();};},[]);
 return <dialog ref={ref} aria-labelledby={id} onCancel={e=>{e.preventDefault();onClose();}} onClick={e=>{if(e.target===e.currentTarget)onClose();}} className="m-auto max-h-[92dvh] w-[min(94vw,850px)] overflow-y-auto rounded-2xl border border-white/15 bg-[#1a2025] p-0 text-[#f3f0e9] shadow-2xl backdrop:bg-black/80 backdrop:backdrop-blur-sm"><div className="p-6 sm:p-8"><div className="mb-6 flex items-center justify-between gap-4"><h2 id={id} className="text-xl font-semibold">{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={20}/></button></div>{children}</div></dialog>;
}

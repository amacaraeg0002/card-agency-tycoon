import { useEffect,useRef } from 'react';
import { CARDS } from '../cardData';
import { compact,money } from '../economy';
import { useGameStore } from '../useGameStore';
const W=1100,H=690;
const DESKS=[[4,5],[3,10],[7,10],[10,7],[10,3]] as const;
export function OfficeCanvas(){
 const ref=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{const canvas=ref.current,ctx=canvas?.getContext('2d');if(!canvas||!ctx)return;const c=ctx;let frame=0;const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const resize=()=>{const rect=canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);canvas.width=Math.max(1,Math.round(rect.width*d));canvas.height=Math.max(1,Math.round(rect.height*d));};const observer=new ResizeObserver(resize);observer.observe(canvas);resize();
 const p=(x:number,y:number,z=0):[number,number]=>[550+(x-y)*28,152+(x+y)*14-z];
 const poly=(pts:[number,number][],fill:string,stroke?:string)=>{c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}};
 const box=(x:number,y:number,w:number,d:number,h:number,top:string,left='#7a8990',right='#5e7079',base=0)=>{poly([p(x,y+d,base),p(x+w,y+d,base),p(x+w,y+d,h+base),p(x,y+d,h+base)],left);poly([p(x+w,y,base),p(x+w,y+d,base),p(x+w,y+d,h+base),p(x+w,y,h+base)],right);poly([p(x,y,h+base),p(x+w,y,h+base),p(x+w,y+d,h+base),p(x,y+d,h+base)],top);};
 const text=(t:string,x:number,y:number,color:string,size=14)=>{c.fillStyle=color;c.font=`600 ${size}px system-ui`;c.textAlign='center';c.fillText(t,x,y);};
 const draw=(now:number)=>{c.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);c.clearRect(0,0,W,H);
 const bg=c.createRadialGradient(530,300,70,530,300,650);bg.addColorStop(0,'#2d3f48');bg.addColorStop(1,'#1a272f');c.fillStyle=bg;c.fillRect(0,0,W,H);
 c.fillStyle='#0b12185c';c.beginPath();c.ellipse(557,536,415,77,0,0,Math.PI*2);c.fill();
 box(0,0,15,15,15,'#a7b0ae','#465a61','#566870',-15);
 poly([p(0,0),p(15,0),p(15,0,126),p(0,0,126)],'#bfc5bd');poly([p(0,0),p(0,15),p(0,15,126),p(0,0,126)],'#98a6a4');
 for(let x=0;x<15;x++)for(let y=0;y<15;y++){const rug=x>=2&&x<=7&&y>=3&&y<=7;poly([p(x,y),p(x+1,y),p(x+1,y+1),p(x,y+1)],rug?((x+y)%2?'#6c8889':'#718e8d'):((x+y)%2?'#bec4b9':'#b6beb4'),'#758a8525');}
 // Windows on the rear wall.
 for(let x=2;x<7;x+=1.7){poly([p(x,.02,37),p(x+1.35,.02,37),p(x+1.35,.02,104),p(x,.02,104)],'#577782','#d4e0d5');poly([p(x+.08,.02,43),p(x+1.27,.02,43),p(x+1.27,.02,99),p(x+.08,.02,99)],'#6e94a0');}
 const sign=p(10.6,.02,75);text('AGENCY ROW',sign[0],sign[1],'#273b40',25);text('SPORTS  /  CULTURE  /  CLIPS',sign[0],sign[1]+19,'#657571',11);
 box(.2,7.7,.75,4,55,'#526564','#61716b','#445c5e');for(let i=0;i<6;i++)box(.27,7.85+i*.55,.6,.2,14,['#e8b070','#d8dfc8','#668f91'][i%3],'#b39f7f','#6c7c73',55);
 box(10.8,1.5,2.8,1.3,22,'#bb7959','#9c614b','#855842');box(10.8,1.5,2.8,.2,39,'#ca9674','#b58265','#9b6d57');box(11.35,3.5,1.6,.85,17,'#d5c6a4');
 for(const [x,y] of [[1.5,1.4],[1.5,12.8],[13,12.7]]){box(x,y,.65,.65,22,'#e3c19d','#ae8d73','#9a7c64');const q=p(x+.3,y+.3,53);for(let i=0;i<6;i++){c.beginPath();c.ellipse(q[0]+Math.sin(i*1.5)*11,q[1]+Math.cos(i*2)*7,9,22,i*.9,0,Math.PI*2);c.fillStyle=i%2?'#54765c':'#708e66';c.fill();}}
 const s=useGameStore.getState();
 const desks=DESKS.map(([x,y],i)=>({x,y,i,staff:s.game.staff[i-1]})).sort((a,b)=>a.x+a.y-b.x-b.y);
 for(const {x,y,i,staff} of desks){const manual=i===0;if(!manual&&!staff){poly([p(x,y),p(x+2.3,y),p(x+2.3,y+1.3),p(x,y+1.3)],'#70867e22','#718a8399');const q=p(x+1.15,y+.7,0);text('+',q[0],q[1]+4,'#6c837e',25);continue;}
 const id=manual?s.game.activeCard:staff?.cardId,active=manual||!!(staff?.cardId&&!staff.paused),color=id?CARDS[id].color:'#83918f';
 for(const [lx,ly] of [[x+.12,y+.12],[x+2,y+.12],[x+.12,y+1],[x+2,y+1]])box(lx,ly,.12,.12,27,'#364c54','#364c54','#263c43');
 box(x,y,2.3,1.3,6,manual?'#d7ad7d':'#bfbaa7','#a69b84','#817f72',27);
 const q=p(x+.9,y+.23,58);c.fillStyle='#213943';c.fillRect(q[0]-23,q[1]-10,49,34);c.fillStyle=active?'#153943':'#3e535b';c.fillRect(q[0]-20,q[1]-7,43,27);
 if(active){for(let k=0;k<5;k++){const h=6+(reduced.matches?8:Math.abs(Math.sin(now/430+k+i))*12);c.fillStyle=k%2?color:'#edaa71';c.fillRect(q[0]-16+k*7,q[1]+14,4,-h);}}
 const key=p(x+1,y+.82,34);poly([[key[0]-13,key[1]-2],[key[0]+8,key[1]-2],[key[0]+17,key[1]+3],[key[0]-4,key[1]+3]],'#46575a');
 const cup=p(x+1.95,y+.5,42);c.fillStyle='#efe4ce';c.fillRect(cup[0]-4,cup[1],8,10);
 const chair=p(x+1.05,y+1.6,11);c.fillStyle='#3b535c';c.beginPath();c.ellipse(chair[0],chair[1],17,9,0,0,Math.PI*2);c.fill();
 const bob=active&&!reduced.matches?Math.sin(now/380+i):0;c.fillStyle=manual?'#d9895e':'#557881';c.fillRect(chair[0]-11,chair[1]-27+bob,22,23);c.fillStyle='#c89672';c.beginPath();c.arc(chair[0],chair[1]-35+bob,9,0,Math.PI*2);c.fill();c.fillStyle='#334449';c.beginPath();c.ellipse(chair[0],chair[1]-40+bob,9,5,0,0,Math.PI*2);c.fill();
 const label=p(x+1,y+2.2);text(manual?'YOUR EDIT BAY':`DESK ${i}${staff?.paused?' · PAUSED':''}`,label[0],label[1]+17,manual?'#2c4a4c':'#617471',12);
 }
 for(const e of s.events){const age=now-e.at;if(age<0||age>2300)continue;const index=e.desk===null?0:s.game.staff.findIndex(d=>d.id===e.desk)+1;if(index<0||index>=DESKS.length)continue;const [x,y]=DESKS[index],q=p(x+1,y,85+(reduced.matches?0:age/45));c.globalAlpha=1-age/2300;text(`+${compact(e.result.views)} VIEWS`,q[0],q[1],'#edffd9',17);text(`${e.result.net>=0?'+':''}${money(e.result.net)}`,q[0],q[1]+20,e.result.net>=0?'#e2f3d9':'#ffbbb0',14);c.globalAlpha=1;}
 text('15 × 15  /  STARTER OFFICE',550,647,'#85969d',13);frame=requestAnimationFrame(draw);
 };frame=requestAnimationFrame(draw);return ()=>{cancelAnimationFrame(frame);observer.disconnect();};},[]);
 return <canvas ref={ref} className="block aspect-[110/69] w-full" role="img" aria-label="A 15 by 15 isometric office with your manual edit bay and four staff desk locations. Manage the desks using the controls below."/>;
}

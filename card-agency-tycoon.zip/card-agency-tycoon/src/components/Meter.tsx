import { useCallback,useEffect,useRef,useState } from 'react';
import { Scissors,Crosshair } from 'lucide-react';
import { CARDS } from '../cardData';
import { compact,cycleDuration,money,triangle } from '../economy';
import { useGameStore } from '../useGameStore';
import type { CardId,Yield } from '../types';
export function Meter({cardId,compactMode=false}:{cardId:CardId;compactMode?:boolean}){
 const needle=useRef<HTMLDivElement>(null),origin=useRef(performance.now()),until=useRef(0),position=useRef(1);
 const [frozen,setFrozen]=useState(false),[result,setResult]=useState<Yield|null>(null);const cycle=cycleDuration(CARDS[cardId]);
 const release=useCallback(()=>{const now=performance.now();if(now<until.current||document.hidden)return;const x=triangle((now-origin.current)/1000,cycle),r=useGameStore.getState().manual(x);if(!r)return;position.current=x;until.current=now+900;setFrozen(true);setResult(r);if(needle.current)needle.current.style.left=`${x*100}%`;},[cycle]);
 useEffect(()=>{let frame=0;const draw=(now:number)=>{let x:number;if(until.current>now)x=position.current;else{if(until.current!==0){until.current=0;origin.current=now;setFrozen(false);}x=triangle((now-origin.current)/1000,cycle);}if(needle.current)needle.current.style.left=`${x*100}%`;frame=requestAnimationFrame(draw);};frame=requestAnimationFrame(draw);return ()=>cancelAnimationFrame(frame);},[cycle]);
 useEffect(()=>{const key=(e:KeyboardEvent)=>{if(e.code!=='Space'||e.repeat||document.querySelector('dialog[open]'))return;const target=e.target as HTMLElement|null;if(target?.closest('button,input,select,textarea,a,[contenteditable=true]'))return;e.preventDefault();release();};window.addEventListener('keydown',key);return ()=>window.removeEventListener('keydown',key);},[release]);
 return <section className={compactMode?'':'panel p-6 sm:p-8'} aria-label="Manual clipping station">
 {!compactMode&&<div className="mb-8 flex justify-between"><div><p className="eyebrow">MANUAL CLIPPING STATION</p><h2 className="display mt-2 text-4xl uppercase">Find your moment.</h2></div><Crosshair className="text-[#ff8255]" size={28}/></div>}
 <div className="flex justify-between text-xs text-[#a3acb2]"><span>FLOP <b className="text-rose-300">0.25×</b></span><span>PERFECT <b className="text-[#b8ddb5]">2.50×</b></span><span>GOOD <b className="text-amber-200">1.00×</b></span></div>
 <div className="relative my-5"><div className="relative h-9 overflow-hidden rounded-lg border border-white/10 bg-[#66383b]"><div className="absolute inset-y-0 left-[40%] w-[20%] bg-[#d7b360]"/><div className="absolute inset-y-0 left-[46.5%] w-[7%] bg-[#a4cf98]"/><div className="absolute inset-y-0 left-[49%] w-[2%] bg-white/70"/></div><div ref={needle} className="pointer-events-none absolute -top-2 -bottom-2 left-full w-[3px] -translate-x-1/2 rounded bg-white shadow-[0_0_12px_#fff]" aria-hidden="true"><div className="absolute -top-1 left-1/2 h-2.5 w-2.5 -translate-x-1/2 rotate-45 rounded-sm bg-white"/></div></div>
 <button onClick={release} disabled={frozen} className="primary-button w-full justify-center py-3.5"><Scissors size={18}/>{frozen?'Rendering clip…':'Release clip'}<kbd className="ml-auto rounded border border-black/20 px-1.5 text-xs">SPACE</kbd></button>
 <div className="mt-3 min-h-12 text-center" aria-live="polite">{result?<div className="animate-reveal"><p className={`text-sm font-bold ${result.grade==='Perfect'?'text-[#b8ddb5]':result.grade==='Good'?'text-amber-200':'text-rose-300'}`}>{result.grade==='Perfect'?'GREEN RELEASE!':`${result.grade.toUpperCase()} RELEASE`} <span className="font-normal text-[#d1d5d8]">+{compact(result.views)} views · {money(result.net)}</span></p></div>:<p className="text-xs text-[#939da5]">Click or press Space. Hit green for a viral cut.</p>}</div>
 </section>;
}

import type { CSSProperties } from 'react';
import { LockKeyhole,Sparkles } from 'lucide-react';
import { PARALLELS } from '../cardData';
import { compact,parallelTier } from '../economy';
import type { Card,Owned } from '../types';
export function CardDisplay({card,owned,small=false}:{card:Card;owned?:Owned;small?:boolean}){
 const tier=parallelTier(owned?.views??0),p=PARALLELS[tier];
 const style={'--card-color':card.color} as CSSProperties;
 return <article style={style} className={`card-shell foil-${tier} relative isolate aspect-[3/4.3] w-full overflow-hidden rounded-xl p-[3px]`} aria-label={`${card.name}, ${card.rarity}, ${card.ovr+tier} overall, ${p.name}`}>
 <div className="relative h-full overflow-hidden rounded-[9px] bg-[#101519]">
 <div className="absolute inset-x-0 top-0 h-[76%] bg-[radial-gradient(ellipse_at_center,#435964_0%,#1b2831_60%,#101519_100%)]"/>
 <img src={`${import.meta.env.BASE_URL}${card.photo}`} alt={`${card.name} — ESPN player photo`} decoding="async" className={`absolute inset-x-0 w-full object-center ${card.photoFit==='cover'?'top-0 h-[76%] object-cover':'top-[9%] h-[61%] object-contain'}`}/>
 <div className="absolute inset-0 bg-gradient-to-t from-[#101519] via-[#101519]/5 to-black/10"/>
 <div className="relative flex items-start justify-between p-3"><div className="rounded-md border border-white/30 bg-[#101519]/85 px-2.5 py-2 text-center shadow-xl"><div className="display text-3xl leading-none">{card.ovr+tier}</div><div className="mt-1 text-xs font-semibold">OVR</div></div><div className="flex flex-col items-end gap-2"><span className="rounded border border-white/30 bg-black/65 px-2 py-1 text-xs font-semibold uppercase">{card.rarity}</span>{owned?.locked&&<LockKeyhole size={16} aria-label="Locked"/>}</div></div>
 <div className={`absolute inset-x-0 bottom-0 ${small?'p-3':'p-4'}`}>
 <p className="mb-1 text-xs font-medium tracking-widest text-white/60 uppercase">{card.sport}</p><h3 className={`display leading-[1.04] uppercase ${small?'text-2xl':'text-3xl'}`}>{card.name}</h3>
 {!small&&<div className="mt-2 flex flex-wrap gap-1">{card.quirks.map(q=><span key={q} className="rounded bg-white/10 px-1.5 py-0.5 text-xs text-orange-100">{q}</span>)}</div>}
 {!small&&<div className="mt-3 flex justify-between border-t border-white/15 pt-2 text-xs text-white/75"><span>{compact(card.baseViews)} VIEWS</span><span>${card.cpm.toFixed(2)} CPM</span></div>}
 {!small&&<p className="mt-2 flex items-center gap-1 text-xs text-white/65"><Sparkles size={12}/>{tier===5?'#1 of 1 · This save':p.name}</p>}
 {!small&&card.historic&&<p className="mt-1 text-xs tracking-widest text-amber-200">HISTORIC / 2016</p>}
 </div>{tier>0&&<div className="pointer-events-none absolute inset-0 animate-sheen bg-gradient-to-r from-transparent via-white/20 to-transparent"/>}</div></article>;
}

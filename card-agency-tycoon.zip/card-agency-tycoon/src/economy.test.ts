import { describe,expect,it } from 'vitest';
import { CARDS,PACKS,PARALLELS } from './cardData';
import { assignCard,awardViews,calculateYield,canAssign,canSell,hireStaff,initialGame,nextRandom,openPack,parallelTier,quicksellValue,revealCard,sellDuplicate,stepSecond,timing,triangle } from './economy';
import { validSave } from './persistence';
import type { GameSave,Trend } from './types';
const neutral:Trend={sport:'Baseball',multiplier:1,otherMultiplier:1,remainingMs:180000,defensive:false};
function twoRookies():GameSave{const g=initialGame();return {...g,inventory:{rookie:{count:2,views:0,locked:false}}};}
describe('manual timing',()=>{
 it.each([[0,.25],[.399999,.25],[.4,1],[.464999,1],[.465,2.5],[.49,2.5],[.51,2.5],[.535,2.5],[.5355,1],[.536,1],[.6,1],[.600001,.25],[1,.25]])('classifies %s',(x,m)=>expect(timing(x).multiplier).toBe(m));
 it('rejects invalid positions',()=>{for(const x of [NaN,Infinity,-.1,1.1])expect(()=>timing(x)).toThrow(RangeError);});
 it('uses the requested triangle wave',()=>{expect(triangle(0,1.2)).toBe(1);expect(triangle(.3,1.2)).toBeCloseTo(.5);expect(triangle(.6,1.2)).toBe(0);expect(triangle(1.2,1.2)).toBe(1);});
});
describe('yield math',()=>{
 it('stacks greatness, showtime, timing, and trends once',()=>{const r=calculateYield(CARDS.comeback,0,.5,{...neutral,sport:'Basketball',multiplier:1.5});expect(r.views).toBe(689062);expect(r.gross).toBeCloseTo(12403.116,8);});
 it('grants greatness negative-trend immunity',()=>expect(calculateYield(CARDS.comeback,0,.6,{...neutral,otherMultiplier:.1}).views).toBe(105000));
 it('limits Showtime to the inclusive center window',()=>{expect(calculateYield(CARDS.comeback,0,.49,neutral).views).toBe(459375);expect(calculateYield(CARDS.comeback,0,.51,neutral).views).toBe(459375);expect(calculateYield(CARDS.comeback,0,.510001,neutral).views).toBe(262500);});
 it('applies defensive and KO quirks only in their contexts',()=>{expect(calculateYield(CARDS.gunslinger,0,null,{...neutral,defensive:true}).views).toBe(19200);expect(calculateYield(CARDS.brawler,0,.5,neutral).views).toBe(9000);expect(calculateYield(CARDS.brawler,0,null,neutral).views).toBe(1800);});
 it('does not apply manual sponsors to staff cash',()=>{const m=calculateYield(CARDS.rookie,0,.6,neutral,2),a=calculateYield(CARDS.rookie,0,null,neutral,2,10);expect(m.gross).toBeCloseTo(.9);expect(a.gross).toBeCloseTo(.45);expect(a.wage).toBe(3);expect(a.net).toBeCloseTo(-2.55);});
});
describe('mastery',()=>{
 it('upgrades exactly at all five thresholds',()=>{for(let i=1;i<PARALLELS.length;i++){const v=PARALLELS[i].xp*100;expect(parallelTier(v-1)).toBe(i-1);expect(parallelTier(v)).toBe(i);}});
 it('retains fractional XP between clips',()=>{const r={grade:'Flop' as const,views:75,gross:.1125,wage:0,net:.1125};const g=awardViews(awardViews(initialGame(),'rookie',r),'rookie',r);expect(g.inventory.rookie!.views/100).toBe(1.5);expect(g.totalViews).toBe(150);expect(validSave(g)).toBe(true);});
 it('uses the coating view multiplier only once',()=>expect(calculateYield(CARDS.rookie,30000000,.6,neutral).views).toBe(675));
});
describe('selling and assignments',()=>{
 it('implements every rarity floor and theme bonus',()=>{expect(quicksellValue(CARDS.rookie)).toBe(5);expect(quicksellValue(CARDS.phenom)).toBe(25);expect(quicksellValue(CARDS.brawler)).toBe(100);expect(quicksellValue(CARDS.maestro)).toBe(750);expect(quicksellValue(CARDS.gunslinger)).toBe(4000);expect(quicksellValue(CARDS.comeback)).toBe(11500);expect(quicksellValue(CARDS['historic-tennis'])).toBe(1525);});
 it('protects the first copy and locked duplicates',()=>{expect(canSell(initialGame(),'rookie')).toBe(false);const g=twoRookies(),sold=sellDuplicate(g,'rookie');expect(sold.cash).toBe(g.cash+5);expect(sold.inventory.rookie!.count).toBe(1);expect(sellDuplicate(sold,'rookie')).toBe(sold);g.inventory.rookie!.locked=true;expect(canSell(g,'rookie')).toBe(false);});
 it('protects assigned copies and enforces rarity caps',()=>{let g=hireStaff(twoRookies(),'intern');const id=g.staff[0].id;g=assignCard(g,'rookie',id);expect(canSell(g,'rookie')).toBe(false);expect(validSave(g)).toBe(true);g={...g,inventory:{...g.inventory,maestro:{count:1,views:0,locked:false}}};expect(canAssign(g,'maestro',id)).toBe(false);expect(canAssign(g,'rookie',id)).toBe(true);});
 it('limits staff to four',()=>{let g={...initialGame(),cash:100000};for(let i=0;i<5;i++)g=hireStaff(g,'intern');expect(g.staff).toHaveLength(4);expect(g.cash).toBe(98000);});
});
describe('packs',()=>{
 it('normalizes the independent odds',()=>{for(const p of Object.values(PACKS))expect(p.odds.reduce((sum,[,p])=>sum+p,0)).toBeCloseTo(1,12);});
 it('produces deterministic draws',()=>{expect(openPack(initialGame(),'starter')).toEqual(openPack(initialGame(),'starter'));expect(nextRandom(12345)).toEqual(nextRandom(12345));});
 it('charges once and preserves pending results through JSON roundtrip',()=>{const g=openPack(initialGame(),'starter');expect(g.cash).toBe(2250);expect(g.pending!.cards).toHaveLength(3);expect(openPack(g,'starter')).toBe(g);const saved=JSON.parse(JSON.stringify(g));expect(saved).toEqual(g);expect(validSave(saved)).toBe(true);});
 it('awards on reveal once only',()=>{const g=openPack(initialGame(),'starter');expect(g.inventory).toEqual(initialGame().inventory);const id=g.pending!.cards[0].cardId,before=g.inventory[id]?.count??0,r=revealCard(g,0);expect(r.inventory[id]!.count).toBe(before+1);expect(revealCard(r,0)).toBe(r);expect(revealCard(r,-1)).toBe(r);expect(revealCard(r,.5)).toBe(r);expect(validSave(r)).toBe(true);});
 it('rejects unaffordable purchases',()=>{const g={...initialGame(),cash:249};expect(openPack(g,'starter')).toBe(g);});
});
describe('staff and saves',()=>{
 it('produces on the tenth second with specified wages',()=>{let g=hireStaff(twoRookies(),'intern');g=assignCard(g,'rookie',g.staff[0].id);g={...g,staff:g.staff.map(s=>({...s,paused:false}))};const cash=g.cash;for(let i=0;i<9;i++){const r=stepSecond(g);expect(r.productions).toHaveLength(0);g=r.game;}const r=stepSecond(g);expect(r.productions[0].result.views).toBe(255);expect(r.productions[0].result.net).toBeCloseTo(-2.1675);expect(r.game.cash).toBeCloseTo(cash-2.1675);expect(validSave(r.game)).toBe(true);});
 it('pauses an unaffordable desk without free views',()=>{let g=hireStaff(twoRookies(),'intern');g=assignCard(g,'rookie',g.staff[0].id);g={...g,cash:0,clockMs:9000,staff:g.staff.map(s=>({...s,paused:false}))};const r=stepSecond(g);expect(r.paused).toBe(1);expect(r.productions).toHaveLength(0);expect(r.game.cash).toBe(0);expect(r.game.totalViews).toBe(0);});
 it('rejects corrupt or inconsistent saves',()=>{expect(validSave(initialGame())).toBe(true);for(const bad of [{cash:-1},{cash:NaN},{totalViews:1},{rng:0},{inventory:{}},{sponsor:99}])expect(validSave({...initialGame(),...bad})).toBe(false);});
});

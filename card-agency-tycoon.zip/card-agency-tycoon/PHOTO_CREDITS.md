# Player photo sources

All ten cards use real ESPN photographs, verified September 15, 2026. Photos are bundled locally. Card ratings and earnings are fictional game values, not ESPN ratings. Historic cards use general portraits rather than date-specific photography. ESPN and the athletes do not endorse this game.

| Athlete | Profile | Original image |
| --- | --- | --- |
| Jackson Holliday | [ESPN profile](https://www.espn.com/mlb/player/_/id/5080633/jackson-holliday) | [Photo](https://a.espncdn.com/combiner/i?img=/i/headshots/mlb/players/full/5080633.png) |
| LeBron James | [ESPN profile](https://www.espn.com/nba/player/_/id/1966/lebron-james) | [Photo](https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/1966.png) |
| Patrick Mahomes | [ESPN profile](https://www.espn.com/nfl/player/_/id/3139477/patrick-mahomes) | [Photo](https://a.espncdn.com/combiner/i?img=/i/headshots/nfl/players/full/3139477.png) |
| Lionel Messi | [ESPN profile](https://www.espn.com/soccer/player/_/id/45843/lionel-messi) | [Photo](https://a.espncdn.com/combiner/i?img=/i/headshots/soccer/players/full/45843.png) |
| Alex Pereira | [ESPN profile](https://www.espn.com/mma/fighter/_/id/4705658/alex-pereira) | [Photo](https://a.espncdn.com/photo/2026/0614/r1673047_1296x518_5-2.jpg) |
| Coco Gauff | [ESPN profile](https://www.espn.com/tennis/player/_/id/3626/coco-gauff) | [Photo](https://a.espncdn.com/i/headshots/tennis/players/full/3626.png) |
| Serena Williams | [ESPN profile](https://www.espn.com/tennis/player/_/id/394/serena-williams) | [Photo](https://a.espncdn.com/i/headshots/tennis/players/full/394.png) |
| Conor McGregor | [ESPN profile](https://www.espn.com/mma/fighter/_/id/3022677/conor-mcgregor) | [Photo](https://a.espncdn.com/i/headshots/mma/players/full/3022677.png) |
| Cristiano Ronaldo | [ESPN profile](https://www.espn.com/soccer/player/_/id/22774/cristiano-ronaldo) | [Photo](https://a.espncdn.com/photo/2026/0907/r1712707_1296x518_5-2.jpg) |
| Tom Brady | [ESPN profile](https://www.espn.com/nfl/player/_/id/2330/tom-brady) | [Photo](https://a.espncdn.com/combiner/i?img=/i/headshots/nfl/players/full/2330.png) |
